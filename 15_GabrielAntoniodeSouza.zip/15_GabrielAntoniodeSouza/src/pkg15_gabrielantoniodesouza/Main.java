package pkg15_gabrielantoniodesouza;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double soma, media;
        
        System.out.println("Insira número 1: ");
        double n1 = scanner.nextInt();
        System.out.println("Insira número 2: ");
        double n2 = scanner.nextInt();
        soma=n1 + n2;
        System.out.println(soma);
        media=n1 + n2 /2;
        System.out.println(media);
    }
    
}
