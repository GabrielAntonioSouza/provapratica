package pkg18_gabrielantoniodesouza;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Insira o nome do Lutador:" );
        String nome=scanner.nextLine();
        
        System.out.println("Informe o Peso do Lutador: " );
        Double peso = scanner.nextDouble();
        
        FileWriter arq = new FileWriter("C:\\Users\\aluno\\Desktop\\Lista de Lutadores.txt");
        PrintWriter gravararq = new PrintWriter(arq);
        if(peso < 65){
            gravararq.printf("Nome fornecido: " +nome);
            gravararq.printf("Peso fornecido: " + peso);
            gravararq.printf("O lutador "+nome+" pesa "+peso+" e se enquadra na categoria Pena");
        }else if(peso >=65 && peso<72){
            gravararq.printf("Nome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Leve");
        }else if(peso >=72 && peso <79){
            gravararq.printf("\nNome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Ligeiro");
        }else if(peso >=79 && peso <86){
            gravararq.printf("\nNome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Meio Médio");
        }else if(peso >=86 && peso <93){
            gravararq.printf("\nNome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Médio");
        }else if(peso >=93 && peso <100){
            gravararq.printf("\nNome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Meio Pesado");
        }else if(peso >100){
            gravararq.printf("\nNome fornecido: " +nome+"\n");
            gravararq.printf("\nPeso fornecido: " + peso+"\n");
            gravararq.printf("\nO lutador "+nome+" pesa "+peso+" e se enquadra na categoria Pesado");
        }
        arq.close();
    }
    
}
